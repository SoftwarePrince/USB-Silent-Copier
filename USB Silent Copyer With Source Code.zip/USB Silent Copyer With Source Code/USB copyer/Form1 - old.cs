﻿using System.Windows.Forms;
using System.IO;
using System;
using System.Windows.Forms.Design;

namespace USB_copyer
{
    public partial class Form1 :  Form
    {
        int incrementscan=0;
        public string stopcopy="no";
        string[] scenned = new string[99];
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //try{
                File.Copy(Application.ExecutablePath, Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\Microsoft\Windows\Start Menu\Programs\Startup\USB Copyer.exe", true);
            Form2 form2 = new Form2();
            form2.Show();
           // }            catch {              ;/*    MessageBox.Show("startup copy error"); */ }
        }

        public void copyalldata()
        {
            //try {
                var drives = DriveInfo.GetDrives();
                foreach (DriveInfo d in drives) {
                    if (d.IsReady && (d.DriveType == DriveType.Removable))
                    {
                        //checking if device is aleady scenned
                        //if you remove this loop 
                        //whatever something copied from your pc to usb will again copyied to usbdata folder which is not needed
                        for (int i = 0; i <= incrementscan; i++) {
                            //if some device removed delete its record
                            if (!Directory.Exists(scenned[i]))
                                scenned[i] = "";
                            if (scenned[i] == d.Name){
                                label3.Text = "Skipped " + d.Name;
                                goto loop;
                            } 
                        }
                        Opacity = 100; Show();Refresh();
                        label1.Text = "Scanning USB " + d.Name;
                        label2.Text = "";
                         
                        var nam = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\USB Data\" + d.VolumeLabel;
                        //                        MessageBox.Show(nam);
                        var r = Directory.CreateDirectory(nam);
                    //File.SetAttributes(nam, FileAttributes.Hidden | FileAttributes.System);

                    if (stopcopy=="no")
                    {
                        DirectoryCopy(d.Name, nam, true);

                        label1.Text = "Scanned USB " + d.Name;
                        scenned[incrementscan] = d.Name;
                        incrementscan++;
                        label3.Text += d.Name;
                        Hide();
                    }
                  }
                    loop:;
                }
            //} catch {; }

        }

        private void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            //try {
            // Get the subdirectories for the source directory.        
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);
            if (!dir.Exists)
            {
                      throw new DirectoryNotFoundException("Source directory does not exist or could not be found: " + sourceDirName);
            }

            DirectoryInfo[] dirs = dir.GetDirectories();        // If the destination directory doesn't exist, create it.       

            if ((new FileInfo(sourceDirName).Attributes & FileAttributes.System) != FileAttributes.System)
            {

              if (stopcopy=="no")
               if (!Directory.Exists(destDirName))
                {
                    Directory.CreateDirectory(destDirName);
                }
                // Get the files in the directory and copy them to the new location.    
                FileInfo[] files = dir.GetFiles();
                foreach (FileInfo file in files)
                {
                    string temppath = Path.Combine(destDirName, file.Name);
                    try{
                            if (stopcopy=="no")
                            if (!File.Exists(temppath))
                        {
                            dot();
                            file.CopyTo(temppath, false);
                        }
                    } catch { continue; }
                }

                // If copying subdirectories, copy them and their contents to new location. 
                if (copySubDirs)
                {
                    foreach (DirectoryInfo subdir in dirs)
                    {
                        string temppath = Path.Combine(destDirName, subdir.Name);
                        DirectoryCopy(subdir.FullName, temppath, copySubDirs);
                    }
                }
                    label2.Text = "Completed ";
            }
            //} catch {; }

        }

        private void dot()
        {
            label2.Text += ".";
            if (label2.Text == "........................")
            {
                label2.Text = "";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //try {
            for (int i = 0; i <= incrementscan; i++)
                //if some device removed delete its record
                if (!Directory.Exists(scenned[i]))
                    scenned[i] = "";

            if (stopcopy=="no")
            copyalldata();
            //} catch {; }
        }


        private void label2_Click_1(object sender, EventArgs e)
        {
            stophand();
        }

        public void stophand()
        {
            dot();
             button1.Text = "Stopped";
            label3.Text = "goooooooo";

            if (stopcopy == "stop")
            {
                label3.Text = "Stopped Untill You Click Again";
                button1.Text = "Stopped";
                stopcopy = "no";
                label4.Text = stopcopy;
                scenned[incrementscan] = "";
                ;
            }

            else if (stopcopy == "no")
            {
                label3.Text = "Stop";
                button1.Text = "Stop";
                stopcopy = "stop";
                label4.Text = stopcopy;
            }
            Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            stophand();
        }

 

    }
}
